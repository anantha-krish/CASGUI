package co.jp.ana.cas.gui.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity	
public class CancelFlightInfo {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	private String flightType;
	
	private Date depDate;
	
	private String depAirport;
	
	private String arvAirport;
	
	private String flightNumber;
	
	private String carrierCode;
	
	private String depTime;
	
	private String arvTime;
	
	private String reason;
	
	private String status;
	
	
	public CancelFlightInfo() {}


	public Integer getId() {
		return id;
	}


	public String getFlightType() {
		return flightType;
	}


	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}


	public Date getDepDate() {
		return depDate;
	}


	public void setDepDate(Date depDate) {
		this.depDate = depDate;
	}


	public String getDepAirport() {
		return depAirport;
	}


	public void setDepAirport(String depAirport) {
		this.depAirport = depAirport;
	}


	public String getArvAirport() {
		return arvAirport;
	}


	public void setArvAirport(String arvAirport) {
		this.arvAirport = arvAirport;
	}


	public String getFlightNumber() {
		return flightNumber;
	}


	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}


	public String getCarrierCode() {
		return carrierCode;
	}


	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}


	public String getDepTime() {
		return depTime;
	}


	public void setDepTime(String depTime) {
		this.depTime = depTime;
	}


	public String getArvTime() {
		return arvTime;
	}


	public void setArvTime(String arvTime) {
		this.arvTime = arvTime;
	}


	public String getReason() {
		return reason;
	}


	public void setReason(String reason) {
		this.reason = reason;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	
	


	
   
}
