package co.jp.ana.cas.gui.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import co.jp.ana.cas.gui.entity.CancelFlightInfo;
import co.jp.ana.cas.gui.entity.CancelFlightSearchInfo;
import co.jp.ana.cas.gui.repo.CancelFlightInfoRepo;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class CancelFlightInfoController {

	@Autowired
	CancelFlightInfoRepo repo;

	@GetMapping("cas-gui/cancel-flight")
	public List<CancelFlightInfo> getAllCancelFlightInfo() {
		return repo.findAll();
	}

	@GetMapping("cas-gui/cancel-flight/{id}")
	public CancelFlightInfo getCancelFlightInfo(@PathVariable Integer id) {
		return repo.findById(id).get();
	}
	
	private long getTimeDuration(String startTime, String endTime ) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
	    Date d1 = sdf.parse(startTime);
	    Date d2 = sdf.parse(endTime);
	    return d2.getTime() - d1.getTime(); 
	}
	
	@PostMapping("cas-gui/cancel-flight/search")
	public List<CancelFlightInfo> searchFlightInfo(@RequestBody CancelFlightSearchInfo cancelFlightSearchInfo) throws Exception {
		CancelFlightInfo cancelFlightInfo = new CancelFlightInfo();
		cancelFlightInfo.setFlightType(cancelFlightSearchInfo.getFlightType());
		cancelFlightInfo.setDepAirport(cancelFlightSearchInfo.getDepAirport());
		cancelFlightInfo.setArvAirport(cancelFlightSearchInfo.getArvAirport());
		cancelFlightInfo.setFlightNumber(cancelFlightSearchInfo.getFlightNumber());
		cancelFlightInfo.setCarrierCode(cancelFlightSearchInfo.getCarrierCode());
		cancelFlightInfo.setReason(cancelFlightSearchInfo.getReason());
		Example<CancelFlightInfo> exampleCancelInfo = Example.of(cancelFlightInfo);
		List<CancelFlightInfo>  cancelFlightInfoList = repo.findAll(exampleCancelInfo);
		List<CancelFlightInfo>  actualResults = new ArrayList<>();
		boolean include;
		for(CancelFlightInfo cancelFlightInfoObj : cancelFlightInfoList) {
			include = true;
			if(cancelFlightSearchInfo.getDepDateStart() != null && cancelFlightInfoObj.getDepDate().compareTo(cancelFlightSearchInfo.getDepDateStart()) < 0) {
				include = false;
			}else if(cancelFlightSearchInfo.getDepDateEnd() != null && cancelFlightInfoObj.getDepDate().compareTo(cancelFlightSearchInfo.getDepDateEnd()) > 0) {
				include = false;
			} else if (cancelFlightSearchInfo.getDepTimeStart() != null && !cancelFlightSearchInfo.getDepTimeStart().equals("00:00") && getTimeDuration(cancelFlightSearchInfo.getDepTimeStart(),cancelFlightInfoObj.getDepTime()) < 0) {
				include = false;
			} else if (cancelFlightSearchInfo.getDepTimeEnd() != null && !cancelFlightSearchInfo.getDepTimeEnd().equals("00:00") && getTimeDuration(cancelFlightSearchInfo.getDepTimeEnd(),cancelFlightInfoObj.getDepTime()) > 0) {
				include = false;
			} else if (cancelFlightSearchInfo.getArvTimeStart() != null && !cancelFlightSearchInfo.getArvTimeStart().equals("00:00") && getTimeDuration(cancelFlightSearchInfo.getArvTimeStart(),cancelFlightInfoObj.getArvTime()) < 0) {
				include = false;
			} else if (cancelFlightSearchInfo.getArvTimeEnd() != null && !cancelFlightSearchInfo.getArvTimeEnd().equals("00:00") && getTimeDuration(cancelFlightSearchInfo.getArvTimeEnd(),cancelFlightInfoObj.getArvTime()) > 0) {
				include = false;
			}
			if(include) {
				actualResults.add(cancelFlightInfoObj);
			}
		}
		
		return actualResults;
	}

	@DeleteMapping("cas-gui/cancel-flight/{id}")
	public ResponseEntity<Void> deleteCancelFlightInfo(@PathVariable Integer id) {
		repo.deleteById(id);
		return ResponseEntity.noContent().build();
	}

	@PutMapping("cas-gui/cancel-flight")
	public ResponseEntity<CancelFlightInfo> updateCancelFlightInfo(@RequestBody CancelFlightInfo cancelFlightInfo) {
		CancelFlightInfo approveCancelFlightInfo = repo.findById(cancelFlightInfo.getId()).get();
		approveCancelFlightInfo.setStatus("APPROVED");
		repo.save(approveCancelFlightInfo);
		return new ResponseEntity<CancelFlightInfo>(approveCancelFlightInfo, HttpStatus.OK);
	}
	
	@PostMapping("cas-gui/cancel-flight/approve")
	public ResponseEntity<CancelFlightInfo> approveCancelFlightInfos(@RequestBody List<CancelFlightInfo> cancelFlightInfos) {
		for(CancelFlightInfo cancelFlightInfo : cancelFlightInfos) {
			CancelFlightInfo approveCancelFlightInfo = repo.findById(cancelFlightInfo.getId()).get();
			approveCancelFlightInfo.setStatus("APPROVED");
			repo.save(approveCancelFlightInfo);
		}
		return ResponseEntity.noContent().build();
	}
	
	@PostMapping("cas-gui/cancel-flight/reject")
	public ResponseEntity<CancelFlightInfo> rejectCancelFlightInfos(@RequestBody List<CancelFlightInfo> cancelFlightInfos) {
		for(CancelFlightInfo cancelFlightInfo : cancelFlightInfos) {
			CancelFlightInfo approveCancelFlightInfo = repo.findById(cancelFlightInfo.getId()).get();
			approveCancelFlightInfo.setStatus("REJECTED");
			repo.save(approveCancelFlightInfo);
		}
		return ResponseEntity.noContent().build();
	}
	
	@PostMapping("cas-gui/cancel-flight/updateReason")
	public ResponseEntity<CancelFlightInfo> updateReasonCancelFlightInfos(@RequestBody List<CancelFlightInfo> cancelFlightInfos) {
		for(CancelFlightInfo cancelFlightInfo : cancelFlightInfos) {
			CancelFlightInfo approveCancelFlightInfo = repo.findById(cancelFlightInfo.getId()).get();
			approveCancelFlightInfo.setReason(cancelFlightInfo.getReason());
			repo.save(approveCancelFlightInfo);
		}
		return ResponseEntity.noContent().build();
	}

	/* will add if required
	 * @PostMapping("cas-gui/cancel-flight") public ResponseEntity<Void>
	 * createCancelFlightInfo(@RequestBody CancelFlightInfo CancelFlightInfo) {
	 * CancelFlightInfo createdCancelFlightInfo = repo.save(CancelFlightInfo); URI
	 * uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
	 * .buildAndExpand(createdCancelFlightInfo.getId()).toUri(); return
	 * ResponseEntity.created(uri).build(); }
	 */

}
