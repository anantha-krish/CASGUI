package co.jp.ana.cas.gui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import co.jp.ana.cas.gui.service.FilesStorageService;

@SpringBootApplication
public class CASGUIServiceApplication implements CommandLineRunner {
	
	@Autowired
	FilesStorageService storageService;

	public static void main(String... args) {
		SpringApplication.run(CASGUIServiceApplication.class, args);
	}

	@Override
	public void run(String... arg) throws Exception {
		storageService.deleteAll();
		storageService.init();
	}
}
