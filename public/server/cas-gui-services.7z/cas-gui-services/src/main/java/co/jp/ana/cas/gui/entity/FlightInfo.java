package co.jp.ana.cas.gui.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity	
public class FlightInfo {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	private String flightNumber;
	
	private Date depDate;
	
	private String depTime;
	
	private String depAirport;
	
	private Date arvDate;
	
	private String arvTime;
	
	private String arvAirport;
	
	private String resource;
	

	private String file;
	
	@Transient
	private String[] deletedFiles;
	
	public FlightInfo() {}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public Date getDepDate() {
		return depDate;
	}

	public void setDepDate(Date depDate) {
		this.depDate = depDate;
	}

	public String getDepTime() {
		return depTime;
	}

	public void setDepTime(String depTime) {
		this.depTime = depTime;
	}

	public String getDepAirport() {
		return depAirport;
	}

	public void setDepAirport(String depAirport) {
		this.depAirport = depAirport;
	}

	public Date getArvDate() {
		return arvDate;
	}

	public void setArvDate(Date arvDate) {
		this.arvDate = arvDate;
	}

	public String getArvTime() {
		return arvTime;
	}

	public void setArvTime(String arvTime) {
		this.arvTime = arvTime;
	}

	public String getArvAirport() {
		return arvAirport;
	}

	public void setArvAirport(String arvAirport) {
		this.arvAirport = arvAirport;
	}

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}


	public Integer getId() {
		return id;
	}
	
	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String[] getDeletedFiles() {
		return deletedFiles;
	}

	public void setDeletedFiles(String[] deletedFiles) {
		this.deletedFiles = deletedFiles;
	}
	
	
   
}
