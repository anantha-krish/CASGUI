package co.jp.ana.cas.gui.entity;

import java.util.Date;



public class CancelFlightSearchInfo {
	
	private String flightType;
	
	private Date depDateStart;
	
	private Date depDateEnd;
	
	private String depAirport;
	
	private String arvAirport;
	
	private String flightNumber;
	
	private String carrierCode;
	
	private String depTimeStart;
	
	private String arvTimeStart;
	
	private String depTimeEnd;
	
	private String arvTimeEnd;
	
	private String reason;
	
	protected CancelFlightSearchInfo() {}

	public String getFlightType() {
		return flightType;
	}

	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}

	public Date getDepDateStart() {
		return depDateStart;
	}

	public void setDepDateStart(Date depDateStart) {
		this.depDateStart = depDateStart;
	}

	public Date getDepDateEnd() {
		return depDateEnd;
	}

	public void setDepDateEnd(Date depDateEnd) {
		this.depDateEnd = depDateEnd;
	}

	public String getDepAirport() {
		return depAirport;
	}

	public void setDepAirport(String depAirport) {
		this.depAirport = depAirport;
	}

	public String getArvAirport() {
		return arvAirport;
	}

	public void setArvAirport(String arvAirport) {
		this.arvAirport = arvAirport;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getCarrierCode() {
		return carrierCode;
	}

	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}

	public String getDepTimeStart() {
		return depTimeStart;
	}

	public void setDepTimeStart(String depTimeStart) {
		this.depTimeStart = depTimeStart;
	}

	public String getArvTimeStart() {
		return arvTimeStart;
	}

	public void setArvTimeStart(String arvTimeStart) {
		this.arvTimeStart = arvTimeStart;
	}

	public String getDepTimeEnd() {
		return depTimeEnd;
	}

	public void setDepTimeEnd(String depTimeEnd) {
		this.depTimeEnd = depTimeEnd;
	}

	public String getArvTimeEnd() {
		return arvTimeEnd;
	}

	public void setArvTimeEnd(String arvTimeEnd) {
		this.arvTimeEnd = arvTimeEnd;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	
	
}
