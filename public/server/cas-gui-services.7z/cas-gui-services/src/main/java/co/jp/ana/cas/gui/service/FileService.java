package co.jp.ana.cas.gui.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import co.jp.ana.cas.gui.entity.FlightInfo;
import co.jp.ana.cas.gui.helper.CSVHelper;
import co.jp.ana.cas.gui.helper.ExcelHelper;
import co.jp.ana.cas.gui.repo.FlightInfoRepo;

@Service
public class FileService {
  @Autowired
  FlightInfoRepo repository;

  public void saveExcel(MultipartFile file) {
    try {
      List<FlightInfo> flightInfos = ExcelHelper.excelToFlightInfos(file.getInputStream());
      repository.saveAll(flightInfos);
    } catch (IOException e) {
      throw new RuntimeException("fail to store excel data: " + e.getMessage());
    }
  }
  
  public void saveCSV(MultipartFile file) {
	    try {
	      List<FlightInfo> flightInfos = CSVHelper.csvToFlightInfos(file.getInputStream());
	      repository.saveAll(flightInfos);
	    } catch (IOException e) {
	      throw new RuntimeException("fail to store csv data: " + e.getMessage());
	    }
	  }

}