package co.jp.ana.cas.gui.controller;

import java.net.URI;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import co.jp.ana.cas.gui.entity.FlightInfo;
import co.jp.ana.cas.gui.helper.CSVHelper;
import co.jp.ana.cas.gui.helper.ExcelHelper;
import co.jp.ana.cas.gui.message.ResponseMessage;
import co.jp.ana.cas.gui.repo.FlightInfoRepo;
import co.jp.ana.cas.gui.service.FileService;
import co.jp.ana.cas.gui.service.FilesStorageService;

import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class FlightInfoController {

	@Autowired
	FlightInfoRepo repo;
	@Autowired
	FilesStorageService storageService;
	
	  @Autowired
	  FileService fileService;

	@GetMapping("cas-gui/flight-info")
	public List<FlightInfo> getAllFlightInfo() {
		return repo.findAll();
	}

	@GetMapping("cas-gui/flight-info/{id}")
	public FlightInfo getFlightInfo(@PathVariable Integer id) {
		return repo.findById(id).get();
	}

	@DeleteMapping("cas-gui/flight-info/{id}")
	public ResponseEntity<Void> deleteFlightInfo(@PathVariable Integer id) {
		FlightInfo flightInfo = repo.findById(id).get();
		storageService.deleteAll(flightInfo.getFlightNumber());
		repo.deleteById(id);
		return ResponseEntity.noContent().build();
	}

	@PutMapping("cas-gui/flight-info")
	public ResponseEntity<FlightInfo> updateFlightInfo(@RequestParam("file") List<MultipartFile> files ,@RequestParam("flightObj") String flightInfoStr) {
		try {
			
			ObjectMapper mapper = new ObjectMapper();
			FlightInfo flightInfo = mapper.readValue(flightInfoStr, FlightInfo.class);
			for(String fileName : flightInfo.getDeletedFiles()) {
				storageService.deleteFile(flightInfo.getFlightNumber(), fileName);
			}
			FlightInfo updatedFlightInfo = repo.save(flightInfo);
			
			for(MultipartFile file : files) {
				storageService.save(file,flightInfo.getFlightNumber());
			}
			return new ResponseEntity<FlightInfo>(updatedFlightInfo, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<FlightInfo>(new FlightInfo() , HttpStatus.EXPECTATION_FAILED);
		}
	}

	@PostMapping("cas-gui/flight-info")
	public ResponseEntity<FlightInfo> createFlightInfo(@RequestParam("file") List<MultipartFile> files ,@RequestParam("flightObj") String flightInfoStr) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			FlightInfo flightInfo = mapper.readValue(flightInfoStr, FlightInfo.class);
			FlightInfo createdFlightInfo = repo.save(flightInfo);
			for(MultipartFile file : files) {
				storageService.save(file,flightInfo.getFlightNumber());
			}
			return new ResponseEntity<FlightInfo>(createdFlightInfo, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<FlightInfo>(new FlightInfo() , HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	@GetMapping("/cas-gui/files/{flightNumber:.+}/{filename:.+}")
	@ResponseBody
	public ResponseEntity<Resource> getFile(@PathVariable String filename,@PathVariable String flightNumber) {
		Resource file = storageService.load(flightNumber,filename);
		if(file!=null){
			return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
				.body(file);
		}
		else {
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION,"inline")
					.body(file);
					
		}
	}
	
	  @PostMapping("/cas-gui/flight-info/upload")
	  public ResponseEntity<ResponseMessage> uploadFile(@RequestParam("file") MultipartFile file) {
	    String message = "";
       if(ExcelHelper.hasExcelFormat(file) || CSVHelper.hasCSVFormat(file))
       {
	      try {
	    	  if (ExcelHelper.hasExcelFormat(file)) {
	        fileService.saveExcel(file);
	        }
	    	  else if(CSVHelper.hasCSVFormat(file)) {
	    		  fileService.saveCSV(file);		  
	    	  }

	        message = "Uploaded the file successfully: " + file.getOriginalFilename();
	        return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
	      } catch (Exception e) {
	        message = "Could not upload the file: " + file.getOriginalFilename() + "!";
	        return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
	      }
       }
	    

	    message = "Please upload an excel or csv file!";
	    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));
	  }


}
