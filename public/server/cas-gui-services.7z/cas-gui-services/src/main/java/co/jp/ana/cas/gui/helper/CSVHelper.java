package co.jp.ana.cas.gui.helper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.web.multipart.MultipartFile;

import co.jp.ana.cas.gui.constants.FlightInfoHeaders;
import co.jp.ana.cas.gui.entity.FlightInfo;

public class CSVHelper {
	public static List<String> TYPE = Arrays.asList("application/vnd.ms-excel","text/csv");

	public static boolean hasCSVFormat(MultipartFile file) {

		if (!TYPE.contains(file.getContentType())) {
			return false;
		}

		return true;
	}

	public static List<FlightInfo> csvToFlightInfos(InputStream is) {
		try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
				CSVParser csvParser = new CSVParser(fileReader,
						CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {

			List<FlightInfo> flightInfos = new ArrayList<FlightInfo>();

			Iterable<CSVRecord> csvRecords = csvParser.getRecords();

			for (CSVRecord csvRecord : csvRecords) {
				FlightInfo flightInfo = new FlightInfo();

				
				flightInfo.setFlightNumber(csvRecord.get(FlightInfoHeaders.FLIGHT_NUMBER.getHeader()));
				flightInfo.setDepDate(extractDate(csvRecord, FlightInfoHeaders.DEPARTURE_DATE.getHeader()));
				flightInfo.setDepTime(csvRecord.get(FlightInfoHeaders.DEPARTURE_TIME.getHeader()));
				flightInfo.setDepAirport(csvRecord.get(FlightInfoHeaders.DEPARTURE_AIRPORT.getHeader()));
				flightInfo.setArvDate(extractDate(csvRecord, FlightInfoHeaders.ARRIVAL_DATE.getHeader()));
				flightInfo.setArvTime(csvRecord.get(FlightInfoHeaders.ARRIVAL_TIME.getHeader()));
				flightInfo.setArvAirport(csvRecord.get(FlightInfoHeaders.ARRIVAL_AIRPORT.getHeader()));
				flightInfo.setResource(csvRecord.get(FlightInfoHeaders.RESOURCE.getHeader()));

				flightInfos.add(flightInfo);
			}

			return flightInfos;
		} catch (IOException e) {
			throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
		}
	}

	private static Date extractDate(CSVRecord csvRecord, String field) {
		String dateString = csvRecord.get(field);
		try {
			return new SimpleDateFormat("dd-MM-yyyy").parse(dateString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}