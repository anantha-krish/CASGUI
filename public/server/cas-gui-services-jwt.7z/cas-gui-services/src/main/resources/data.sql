INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(1,'Domestic','2020-11-02','HND','ITM','NH432','NH','01:00','02:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(2,'Domestic','2020-11-02','HND','ITM','NH756','NH','01:00','03:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(3,'Domestic','2020-11-04','ITM','HND','NH555','NH','03:00','05:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(4,'Domestic','2020-11-04','ITM','HND','NH525','NH','06:00','09:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(5,'Domestic','2020-11-06','NRT','OSA','NH1215','NH','15:00','18:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(6,'Domestic','2020-11-06','NRT','OSA','NH765','NH','18:00','20:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(7,'Domestic','2020-11-07','ITM','HND','NH585','NH','03:00','05:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(8,'Domestic','2020-11-07','NRT','ITM','NH509','NH','12:00','16:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(9,'Domestic','2020-11-07','OSA','NRT','NH692','NH','04:00','05:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(10,'Domestic','2020-11-07','OSA','HND','NH812','NH','01:00','04:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(11,'Domestic','2020-11-08','ITM','OSA','NH109','NH','06:00','10:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(12,'Domestic','2020-11-08','OSA','HND','NH980','NH','06:00','08:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(13,'Domestic','2020-11-08','NRT','OSA','NH678','NH','20:00','21:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(14,'International','2020-11-04','NRT','JFK','NH123','NH','03:00','09:00','Bad Weather','PENDING');

INSERT INTO cancel_flight_info(id,flight_type,dep_date,dep_airport,arv_airport,flight_number,carrier_code,dep_time,arv_time,reason,status)
values(15,'International','2020-11-04','NRT','COK','AI321','AI','12:00','15:00','Bad Weather','PENDING');




