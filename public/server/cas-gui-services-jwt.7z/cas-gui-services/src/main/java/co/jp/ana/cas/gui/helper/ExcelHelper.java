package co.jp.ana.cas.gui.helper;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import co.jp.ana.cas.gui.entity.FlightInfo;

public class ExcelHelper {
	public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	/*
	 * static String[] HEADERs = { "FLIGHT_INFO_ID", "FLIGHT_NUMBER",
	 * "DEPARTURE_DATE", "DEPARTURE_TIME", "DEPARTURE_AIRPORT", "ARRIVAL_DATE",
	 * "ARRIVAL_TIME", "ARRIVAL_AIRPORT", "RESOURCE", "FILE_PATH" };
	 */
	static String SHEET = "Flights Information List";

	public static boolean hasExcelFormat(MultipartFile file) {

		if (!TYPE.equals(file.getContentType())) {
			return false;
		}

		return true;
	}
	

	public static List<FlightInfo> excelToFlightInfos(InputStream is) {
		try {
			Workbook workbook = new XSSFWorkbook(is);

			Sheet sheet = workbook.getSheet(SHEET);
			Iterator<Row> rows = sheet.iterator();

			List<FlightInfo> flightInfos = new ArrayList<FlightInfo>();

			int rowNumber = 0;
			while (rows.hasNext()) {
				Row currentRow = rows.next();

				// skip header
				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}

				Iterator<Cell> cellsInRow = currentRow.iterator();

				FlightInfo flightInfo = new FlightInfo();

				int cellIdx = 0;
			
				while (cellsInRow.hasNext()) {
					Cell currentCell = cellsInRow.next();

					switch (cellIdx) {
					case 0:
						flightInfo.setFlightNumber(currentCell.getStringCellValue());
						break;

					case 1:
						flightInfo.setDepDate(currentCell.getDateCellValue());
						break;

					case 2:
						flightInfo.setDepTime(getCellTime(currentCell));
						break;

					case 3:
						flightInfo.setDepAirport(currentCell.getStringCellValue());
						break;

					case 4:
						flightInfo.setArvDate(currentCell.getDateCellValue());
						break;

					case 5:
						flightInfo.setArvTime(getCellTime(currentCell));
						break;

					case 6:
						flightInfo.setArvAirport(currentCell.getStringCellValue());
						break;

					case 7:
						flightInfo.setResource(currentCell.getStringCellValue());
						break;

					case 8:
						flightInfo.setFile(currentCell.getStringCellValue());
						break;

					default:
						break;
					}

					cellIdx++;
				}

				flightInfos.add(flightInfo);
			}

			workbook.close();

			return flightInfos;
		} catch (IOException e) {
			throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
		}
	}

	private static String getCellTime(Cell currentCell) {
		SimpleDateFormat formatTime = new SimpleDateFormat("HH:mm");
		String cellTimeValue = formatTime.format(currentCell.getDateCellValue());
		return cellTimeValue;
	}
}