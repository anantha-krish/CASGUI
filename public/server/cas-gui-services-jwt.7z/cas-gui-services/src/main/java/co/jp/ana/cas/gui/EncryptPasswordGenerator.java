package co.jp.ana.cas.gui;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
/** 
 * This class is created to encrypt password of a new user
 *  before adding to db / in memory (has no relation with application
 * **/
public class EncryptPasswordGenerator {
	
	public static void main(String args[])
	{
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		
		for(int i=0;i<10;i++)
		{  // put your user password instead of dummy
			String encodedPassword = encoder.encode("dummy");
			System.out.println(encodedPassword);
		}
		
	}
}
