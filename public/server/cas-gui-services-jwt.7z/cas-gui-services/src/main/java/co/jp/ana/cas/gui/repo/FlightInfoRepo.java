package co.jp.ana.cas.gui.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import co.jp.ana.cas.gui.entity.FlightInfo;

@Repository
public interface FlightInfoRepo extends JpaRepository<FlightInfo, Integer> {

}
