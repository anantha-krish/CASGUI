package co.jp.ana.cas.gui.service;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FilesStorageServiceImpl implements FilesStorageService {

	private final Path root = Paths.get("uploads");

	@Override
	public void init() {
		try {
			Files.createDirectory(root);
		} catch (IOException e) {
			throw new RuntimeException("Could not initialize folder for upload!");
		}
	}
	
	@Override
	public void save(MultipartFile file,String flightNumber) {
		String fileDir ="uploads/"+flightNumber;
		Path cusRoot = Paths.get(fileDir);
		
		try {
			if(!Files.exists(cusRoot)) {
				Files.createDirectory(cusRoot);
			}
			Files.copy(file.getInputStream(), cusRoot.resolve(file.getOriginalFilename()),StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			throw new RuntimeException("Could not store the file. Error: " + e.getMessage());
		}
	}

	@Override
	public Resource load(String flightNumber,String filename) {
		try {
			String fileDir ="uploads/"+flightNumber;
			Path cusRoot = Paths.get(fileDir);
			Path file = cusRoot.resolve(filename);
			Resource resource = new UrlResource(file.toUri());

			if (resource.exists() || resource.isReadable()) {
				
				return resource;
			} else {
				throw new RuntimeException("Could not read the file!");
			}
		} catch (MalformedURLException e) {
			throw new RuntimeException("Error: " + e.getMessage());
		}
	}
	
	@Override
	public void deleteFile(String flightNumber,String filename) {
		try {
			String fileDir ="uploads/"+flightNumber;
			Path cusRoot = Paths.get(fileDir);
			Path file = cusRoot.resolve(filename);
			Files.delete(file);
			
		}catch (Exception e) {
			throw new RuntimeException("Could not delete the file. Error: " + e.getMessage());
		}
	}

	@Override
	public void deleteAll(String flightNumber) {
		try {
			String fileDir ="uploads/"+flightNumber;
			Path cusRoot = Paths.get(fileDir);
			FileSystemUtils.deleteRecursively(cusRoot.toFile());
			
		}catch (Exception e) {
			throw new RuntimeException("Could not delete the file. Error: " + e.getMessage());
		}
		
	}

	@Override
	public void deleteAll() {
		FileSystemUtils.deleteRecursively(root.toFile());
	}

	@Override
	public Stream<Path> loadAll() {
		try {
			return Files.walk(this.root, 1).filter(path -> !path.equals(this.root)).map(this.root::relativize);
		} catch (IOException e) {
			throw new RuntimeException("Could not load the files!");
		}
	}
}