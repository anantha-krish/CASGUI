package co.jp.ana.cas.gui.constants;

public enum FlightInfoHeaders {
	
	FLIGHT_INFO_ID("FLIGHT_INFO_ID"), FLIGHT_NUMBER("FLIGHT_NUMBER"), DEPARTURE_DATE("DEPARTURE_DATE"),
	DEPARTURE_TIME("DEPARTURE_TIME"), DEPARTURE_AIRPORT("DEPARTURE_AIRPORT"), ARRIVAL_DATE("ARRIVAL_DATE"),
	ARRIVAL_TIME("ARRIVAL_TIME"), ARRIVAL_AIRPORT("ARRIVAL_AIRPORT"), RESOURCE("RESOURCE");
	
	private String header;
	
	FlightInfoHeaders(String header) {
		this.header = header;
	}
	
	public String getHeader() {
		return this.header;
	}
	
}

