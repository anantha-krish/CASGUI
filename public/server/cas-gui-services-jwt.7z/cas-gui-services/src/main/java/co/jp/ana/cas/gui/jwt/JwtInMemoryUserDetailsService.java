package co.jp.ana.cas.gui.jwt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class JwtInMemoryUserDetailsService implements UserDetailsService {

  static List<JwtUserDetails> inMemoryUserList = new ArrayList<>();

  static {
    inMemoryUserList.add(new JwtUserDetails(1L, "cas001",
        "$2a$10$tzrLuVue/Uxn4HI3qpM5Z.akS4rwGNwHkgQ3uMUTrKC2/BXR.IGXe", Arrays.asList("ADMIN","USER")));
    inMemoryUserList.add(new JwtUserDetails(2L, "cas002",
            "$2a$10$Js6Fpk6Icd0cFjezqS5i1.ogwyWHaui.xUzAFDAL/4ltWaQfNwiyi", Arrays.asList("USER")));
  
  }

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    Optional<JwtUserDetails> findFirst = inMemoryUserList.stream()
        .filter(user -> user.getUsername().equals(username)).findFirst();

    if (!findFirst.isPresent()) {
      throw new UsernameNotFoundException(String.format("USER_NOT_FOUND '%s'.", username));
    }

    return findFirst.get();
  }

}


